Custom Pseudorandom Number Generator (PRNG) with Distribution Analysis

This project presents a custom-designed **Pseudorandom Number Generator (PRNG)** based on a modified **Linear Congruential Generator (LCG)** algorithm with added non-linear behavior using a sine function. The objective is to evaluate the randomness of the generator by analyzing **uniformity** and **dependency** of the outputs using visual plots.

 PRNG Algorithm

The generator uses the following formula:


Where:

- `a`, `c`, and `m` are constants
- `X[0]` is the seed
- `sin(X[n])` introduces non-linearity to enhance randomness

 Output Visualizations

Two key visualizations are used to analyze the generator:

 Uniformity Check (Histogram)

This plot checks whether the output values are uniformly distributed.

![Uniformity](plots/uniformity.png)



Dependency Check (Scatter Plot)

This scatter plot of `X[n]` vs `X[n+1]` checks if there’s any observable dependency between consecutive numbers.

![Dependency](plots/dependency.png)



How to Run
 1. Install dependencies

Make sure you have Python installed. Then run:

```bash
pip install -r requirements.txt
