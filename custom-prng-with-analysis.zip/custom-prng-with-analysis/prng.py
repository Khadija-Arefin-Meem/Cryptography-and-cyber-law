import numpy as np
import matplotlib.pyplot as plt
import os

# Ensure plots/ folder exists
os.makedirs("plots", exist_ok=True)

def custom_prng(seed=12345, size=10000, a=1103515245, c=12345, m=2**31):
    numbers = []
    x = seed
    for _ in range(size):
        x = (a * x + c + np.sin(x)) % m
        numbers.append(x / m)  # Normalize between 0 and 1
    return np.array(numbers)

# Generate numbers
nums = custom_prng()

plt.figure(figsize=(12, 5))

# Plot histogram to show uniformity
plt.subplot(1, 2, 1)
plt.hist(nums, bins=50, color='skyblue', edgecolor='black')
plt.title("Uniformity: Histogram of PRNG Output")
plt.xlabel("Value")
plt.ylabel("Frequency")

# Save histogram
plt.savefig("plots/uniformity.png")  # ✅ Save the first plot

# Plot scatter of consecutive values to check dependency
plt.subplot(1, 2, 2)
plt.scatter(nums[:-1], nums[1:], alpha=0.3, s=1)
plt.title("Dependency Check: X[n] vs X[n+1]")
plt.xlabel("X[n]")
plt.ylabel("X[n+1]")
plt.tight_layout()

# Save scatter plot
plt.savefig("plots/dependency.png")  # ✅ Save the second plot

plt.show()
